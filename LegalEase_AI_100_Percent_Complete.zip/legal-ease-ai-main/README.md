# ⚖️ LegalEase AI — Complete Project

LegalEase AI is a Streamlit application that coordinates three LangGraph agents for legal-information workflows:

- **Legal Researcher** — legal research, cases and precedents
- **Contract Analyst** — contract/document review
- **Legal Strategist** — risks, options and next steps

> **Important:** This application provides legal-information assistance. It is not a law firm and does not replace advice from a qualified lawyer.

## 1. Requirements

- Python 3.11–3.13
- A Google Gemini, OpenAI or Groq API key
- Optional Tavily API key for web research
- `uv` is recommended, but standard `pip` also works

## 2. Setup with uv

```bash
uv sync
cp .env.example .env
```

Edit `.env` and set your chosen provider key. For Gemini:

```env
LLM_PROVIDER=google_genai
LLM_MODEL=gemini-2.5-flash
GOOGLE_API_KEY=your_key_here
ENABLE_WEB_SEARCH=true
TAVILY_API_KEY=your_tavily_key_here
```

Start the app:

```bash
uv run streamlit run streamlit_app.py
```

## 3. Setup with pip

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -e .
```

Then:

```bash
streamlit run streamlit_app.py
```

## 4. Using the app

1. Open the Streamlit URL shown in the terminal.
2. Upload one or more PDF legal documents.
3. Wait for the document knowledge base to initialize.
4. Ask a question in the chat.
5. Use Quick Actions for Contract Review, Legal Research, Risk Assessment or Strategy.

The app uses PDF extraction, chunking, Hugging Face embeddings and Chroma retrieval before delegating work to the appropriate LangGraph specialist.

## 5. Environment variables

| Variable | Purpose |
|---|---|
| `LLM_PROVIDER` | `google_genai`, `openai`, or `groq` |
| `LLM_MODEL` | Model name for the provider |
| `LLM_TEMPERATURE` | Model temperature |
| `GOOGLE_API_KEY` | Gemini credential |
| `OPENAI_API_KEY` | OpenAI credential |
| `GROQ_API_KEY` | Groq credential |
| `ENABLE_WEB_SEARCH` | Enable Tavily integration |
| `TAVILY_API_KEY` | Optional web-search credential |
| `EMBEDDING_MODEL` | Sentence-transformers model |
| `CHUNK_SIZE` | PDF chunk size |
| `CHUNK_OVERLAP` | PDF overlap |
| `RETRIEVAL_K` | Number of retrieved chunks |

## 6. Testing

Syntax check without installing dependencies:

```bash
python -m compileall streamlit_app.py legal_agents_workflow.py utils.py
```

After installing dependencies:

```bash
pytest
```

Optional linting:

```bash
ruff check .
```

## 7. Docker

```bash
docker build -t legalease-ai .
docker run --env-file .env -p 8501:8501 legalease-ai
```

Open `http://localhost:8501`.

## 8. Project structure

```text
legal-ease-ai-main/
├── streamlit_app.py
├── legal_agents_workflow.py
├── utils.py
├── pyproject.toml
├── .env.example
├── Dockerfile
├── .dockerignore
├── .streamlit/config.toml
├── tests/test_utils.py
├── pdfs/.gitkeep
├── resources/
└── README.md
```

## 9. Production notes

- Never commit `.env` or API keys.
- Verify current law and jurisdiction before relying on any output.
- For sensitive client material, review your organization's privacy and retention requirements before uploading files to third-party AI services.
- Web research is optional; when Tavily is not configured, the application remains usable for document-based analysis.
