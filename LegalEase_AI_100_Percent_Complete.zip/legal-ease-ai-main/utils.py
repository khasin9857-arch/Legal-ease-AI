"""Shared utilities for LegalEase AI.

The functions in this module are intentionally lazy: importing the module does
not create network clients or download embedding models. This makes Streamlit
startup and automated syntax checks more reliable.
"""
from __future__ import annotations

import os
from datetime import datetime
from functools import lru_cache

from dotenv import load_dotenv

load_dotenv()


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def get_config() -> dict[str, object]:
    """Return validated application configuration."""
    provider = os.getenv("LLM_PROVIDER", "google_genai").strip().lower()
    model = os.getenv("LLM_MODEL", "gemini-2.5-flash").strip()
    try:
        temperature = float(os.getenv("LLM_TEMPERATURE", "0.1"))
    except ValueError:
        temperature = 0.1
    temperature = max(0.0, min(2.0, temperature))

    return {
        "provider": provider,
        "model": model,
        "temperature": temperature,
        "enable_web_search": _env_bool("ENABLE_WEB_SEARCH", True),
        "embedding_model": os.getenv(
            "EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
        ),
        "chunk_size": int(os.getenv("CHUNK_SIZE", "1200")),
        "chunk_overlap": int(os.getenv("CHUNK_OVERLAP", "200")),
        "retrieval_k": int(os.getenv("RETRIEVAL_K", "5")),
    }


def validate_environment() -> list[str]:
    """Return configuration problems without exposing secret values."""
    cfg = get_config()
    provider = str(cfg["provider"])
    problems: list[str] = []

    key_map = {
        "google_genai": "GOOGLE_API_KEY",
        "openai": "OPENAI_API_KEY",
        "groq": "GROQ_API_KEY",
    }
    key_name = key_map.get(provider)
    if key_name and not os.getenv(key_name):
        problems.append(f"Missing {key_name} for LLM_PROVIDER={provider}.")

    if bool(cfg["enable_web_search"]) and not os.getenv("TAVILY_API_KEY"):
        problems.append(
            "TAVILY_API_KEY is not configured; web research will be disabled."
        )
    return problems


@lru_cache(maxsize=1)
def get_embeddings():
    """Create the Hugging Face embedding model once per Python process."""
    from langchain_huggingface import HuggingFaceEmbeddings

    model_name = str(get_config()["embedding_model"])
    return HuggingFaceEmbeddings(model_name=model_name)


def create_llm():
    """Create the configured LangChain chat model."""
    from langchain.chat_models import init_chat_model

    cfg = get_config()
    return init_chat_model(
        model=str(cfg["model"]),
        model_provider=str(cfg["provider"]),
        temperature=float(cfg["temperature"]),
    )


def get_today_str() -> str:
    """Get today's date in a portable human-readable format."""
    return datetime.now().strftime("%a %b %d, %Y")
