import os

from utils import get_config, get_today_str, validate_environment


def test_date_format_is_portable():
    assert len(get_today_str()) >= 10


def test_config_defaults(monkeypatch):
    monkeypatch.delenv("LLM_PROVIDER", raising=False)
    monkeypatch.delenv("LLM_MODEL", raising=False)
    cfg = get_config()
    assert cfg["provider"] == "google_genai"
    assert cfg["model"] == "gemini-2.5-flash"


def test_missing_provider_key_is_reported(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "google_genai")
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    monkeypatch.setenv("ENABLE_WEB_SEARCH", "false")
    assert any("GOOGLE_API_KEY" in item for item in validate_environment())
