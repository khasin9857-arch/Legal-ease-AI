"""LangGraph multi-agent workflow used by LegalEase AI."""
from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.messages import HumanMessage
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.tools.retriever import create_retriever_tool
from langchain_chroma import Chroma
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent
from langgraph_supervisor import create_supervisor

from utils import create_llm, get_config, get_embeddings

load_dotenv()


class LegalAgentsWorkflow:
    """Coordinate researcher, contract analyst and strategist agents."""

    def __init__(
        self,
        documents: Optional[List[Document]] = None,
        llm=None,
        embeddings=None,
        pdf_folder: str = "pdfs",
        use_memory: bool = True,
    ):
        self.pdf_folder = pdf_folder
        self.use_memory = use_memory
        self.documents = (
            documents if documents is not None else self._load_default_documents()
        )
        self.llm = llm if llm is not None else create_llm()
        self.embeddings = embeddings if embeddings is not None else get_embeddings()
        self.db = None
        self.retriever = None
        self.retriever_tool = None
        self.search_tool = self._build_search_tool()
        self.memory = MemorySaver() if use_memory else None

        if self.documents:
            self._build_knowledge_base(self.documents)
        self._init_agents()
        self.workflow = self._build_supervisor()

    def _build_search_tool(self):
        """Create Tavily only when a key is available."""
        cfg = get_config()
        if not bool(cfg["enable_web_search"]) or not os.getenv("TAVILY_API_KEY"):
            return None
        try:
            from langchain_tavily import TavilySearch

            return TavilySearch(max_results=3)
        except Exception:
            # The application remains usable with document-only analysis.
            return None

    def _build_knowledge_base(self, documents: List[Document]) -> None:
        """Create an isolated Chroma collection for this workflow instance."""
        collection_name = f"legal_ease_{uuid.uuid4().hex[:12]}"
        self.db = Chroma.from_documents(
            documents=documents,
            embedding=self.embeddings,
            collection_name=collection_name,
        )
        k = int(get_config()["retrieval_k"])
        self.retriever = self.db.as_retriever(
            search_type="similarity", search_kwargs={"k": k}
        )
        self.retriever_tool = create_retriever_tool(
            self.retriever,
            "document_retriever",
            "Search the uploaded legal documents. Use this before making document-specific claims.",
        )

    def _load_default_documents(self) -> List[Document]:
        """Load PDFs from the optional local pdfs directory."""
        folder = Path(self.pdf_folder)
        if not folder.exists():
            return []

        raw_docs: list[Document] = []
        for path in sorted(folder.glob("*.pdf")):
            try:
                pages = PyPDFLoader(str(path)).load()
                for page in pages:
                    page.metadata["source"] = path.name
                raw_docs.extend(pages)
            except Exception:
                # One corrupt PDF should not prevent the remaining documents from loading.
                continue

        if not raw_docs:
            return []

        cfg = get_config()
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=int(cfg["chunk_size"]),
            chunk_overlap=int(cfg["chunk_overlap"]),
        )
        return splitter.split_documents(raw_docs)

    def _init_agents(self) -> None:
        researcher_tools = []
        if self.retriever_tool:
            researcher_tools.append(self.retriever_tool)
        if self.search_tool:
            researcher_tools.append(self.search_tool)

        researcher_prompt = """
You are Legal Researcher, a research assistant inside LegalEase AI.

Rules:
- If uploaded documents exist, use document_retriever before making document-specific claims.
- Use web search only when available and useful; never pretend a search was performed if it was not.
- Distinguish the user's jurisdiction and the jurisdiction of any source.
- Cite sources or document names/sections when the tools provide them.
- Do not invent cases, statutes, quotations, citations, or legal authorities.
- State uncertainty when information is missing or jurisdiction is unclear.
- Provide concise, structured research findings.
- This is legal-information assistance, not a substitute for a licensed lawyer.
""".strip()

        self.legal_researcher = create_react_agent(
            self.llm,
            researcher_tools,
            prompt=researcher_prompt,
            name="legal_researcher",
        )

        analyst_tools = [self.retriever_tool] if self.retriever_tool else []
        analyst_prompt = """
You are Contract Analyst, a document-review specialist inside LegalEase AI.

Rules:
- For uploaded documents, use document_retriever first.
- Identify parties, dates, term, payment, obligations, termination, liability, indemnity,
  confidentiality, dispute resolution, governing law, renewal and unusual clauses when present.
- Quote only short excerpts when necessary and identify the source document/page when available.
- Separate observed text from your interpretation.
- Never invent missing clauses or facts.
- Flag ambiguity and material risk for human legal review.
- This is legal-information assistance, not a substitute for a licensed lawyer.
""".strip()

        self.contract_analyst = create_react_agent(
            self.llm,
            analyst_tools,
            prompt=analyst_prompt,
            name="contract_analyst",
        )

        strategist_tools = []
        if self.retriever_tool:
            strategist_tools.append(self.retriever_tool)
        if self.search_tool:
            strategist_tools.append(self.search_tool)

        strategist_prompt = """
You are Legal Strategist, a structured planning assistant inside LegalEase AI.

Rules:
- Use uploaded-document retrieval before document-specific conclusions.
- Turn verified facts and research into options, risks, dependencies and next steps.
- Do not present an option as guaranteed to succeed.
- Identify assumptions and missing information.
- Consider jurisdiction and deadlines when known, and tell the user when they need confirmation.
- Never invent law, facts, citations or outcomes.
- This is legal-information assistance, not a substitute for a licensed lawyer.
""".strip()

        self.legal_strategist = create_react_agent(
            self.llm,
            strategist_tools,
            prompt=strategist_prompt,
            name="legal_strategist",
        )

    def _build_supervisor(self):
        supervisor_prompt = """
You are the LegalEase AI team coordinator.
Delegate every substantive request to one or more specialist agents.

Routing:
- Contract clauses, obligations, document interpretation -> contract_analyst
- Cases, statutes, precedents, legal research -> legal_researcher
- Risk, compliance, options, planning and next steps -> legal_strategist
- Mixed requests may use specialists sequentially.

Do not invent legal facts. Keep the final response grounded in the specialist output.
Ask for jurisdiction or missing document details when they materially affect the answer.
""".strip()

        supervisor = create_supervisor(
            model=self.llm,
            agents=[
                self.legal_researcher,
                self.contract_analyst,
                self.legal_strategist,
            ],
            prompt=supervisor_prompt,
            add_handoff_back_messages=True,
            output_mode="full_history",
        )
        return supervisor.compile(checkpointer=self.memory) if self.use_memory else supervisor.compile()

    def analyze_document(
        self, query: str, analysis_type: str = "Custom Query", thread_id: str = "default"
    ):
        """Run a synchronous analysis and return the LangGraph state."""
        if not query or not query.strip():
            raise ValueError("Query cannot be empty.")
        state = {"messages": [HumanMessage(content=query.strip())]}
        if self.use_memory:
            return self.workflow.invoke(
                state, config={"configurable": {"thread_id": thread_id}}
            )
        return self.workflow.invoke(state)

    def stream_analysis(self, query: str, thread_id: str = "default"):
        """Stream workflow events for callers that want progress updates."""
        if not query or not query.strip():
            raise ValueError("Query cannot be empty.")
        state = {"messages": [HumanMessage(content=query.strip())]}
        if self.use_memory:
            return self.workflow.stream(
                state, config={"configurable": {"thread_id": thread_id}}
            )
        return self.workflow.stream(state)

    def add_documents(self, documents: List[Document]) -> None:
        """Add documents and rebuild retrieval-enabled agents when needed."""
        if not documents:
            return
        self.documents.extend(documents)
        if self.db is None:
            self._build_knowledge_base(documents)
            self._init_agents()
            self.workflow = self._build_supervisor()
        else:
            self.db.add_documents(documents)

    def clear_documents(self) -> None:
        """Remove the current workflow knowledge base."""
        if self.db is not None:
            try:
                self.db.delete_collection()
            except Exception:
                pass
        self.db = None
        self.retriever = None
        self.retriever_tool = None
        self.documents = []
        self._init_agents()
        self.workflow = self._build_supervisor()


if __name__ == "__main__":
    print("LegalEase AI workflow module loaded. Run streamlit_app.py to launch the UI.")
