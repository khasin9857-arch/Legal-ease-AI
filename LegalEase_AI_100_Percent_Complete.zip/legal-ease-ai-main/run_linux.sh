#!/usr/bin/env bash
set -e
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
[ -f .env ] || cp .env.example .env
streamlit run streamlit_app.py
