from __future__ import annotations

import hashlib
import os
import tempfile
from typing import List, Optional

import streamlit as st
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from legal_agents_workflow import LegalAgentsWorkflow
from utils import get_config, validate_environment

st.set_page_config(
    page_title="LegalEase AI",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
<style>
.main-header {font-size:3rem;font-weight:800;color:#1f4e79;text-align:center;margin-bottom:.25rem;}
.sub-header {font-size:1.45rem;color:#2e5984;margin:1rem 0;border-bottom:2px solid #e6f3ff;padding-bottom:.5rem;}
.agent-card {background:#f8f9fa;padding:.9rem;border-radius:10px;border-left:4px solid #007acc;margin:.5rem 0;}
.status-card {padding:1rem;border-radius:10px;border:1px solid #dee2e6;background:#f8f9fa;margin:.5rem 0;}
.disclaimer {font-size:.8rem;color:#666;padding:.75rem;border-top:1px solid #ddd;margin-top:1rem;}
</style>
""",
    unsafe_allow_html=True,
)


def initialize_session_state() -> None:
    defaults = {
        "workflow": None,
        "chat_history": [],
        "last_files_signature": None,
        "documents_loaded": False,
        "thread_id": hashlib.sha256(os.urandom(32)).hexdigest()[:16],
        "last_error": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def load_documents_from_upload(uploaded_files) -> List[Document]:
    documents: List[Document] = []
    cfg = get_config()

    for uploaded_file in uploaded_files:
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(uploaded_file.getvalue())
                tmp_path = tmp.name

            pages = PyPDFLoader(tmp_path).load()
            for page in pages:
                page.metadata["source"] = uploaded_file.name
                page.metadata["uploaded_file"] = uploaded_file.name
            documents.extend(pages)
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.unlink(tmp_path)

    if not documents:
        return []

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=int(cfg["chunk_size"]),
        chunk_overlap=int(cfg["chunk_overlap"]),
    )
    return splitter.split_documents(documents)


def files_signature(uploaded_files) -> str:
    digest = hashlib.sha256()
    for f in uploaded_files:
        data = f.getvalue()
        digest.update(f.name.encode("utf-8"))
        digest.update(str(len(data)).encode("ascii"))
        digest.update(hashlib.sha256(data).digest())
    return digest.hexdigest()


def create_workflow(documents: Optional[List[Document]] = None) -> LegalAgentsWorkflow:
    return LegalAgentsWorkflow(documents=documents, use_memory=True)


def _extract_final_response(result) -> str:
    messages = result.get("messages", []) if isinstance(result, dict) else []
    candidates: list[str] = []
    for message in messages:
        content = getattr(message, "content", "")
        if isinstance(content, str) and content.strip():
            candidates.append(content.strip())
        elif isinstance(content, list):
            text_parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            combined = "\n".join(x for x in text_parts if x).strip()
            if combined:
                candidates.append(combined)
    return candidates[-1] if candidates else "No response was returned by the AI workflow."


def process_message(prompt: str) -> None:
    prompt = prompt.strip()
    if not prompt:
        return
    workflow = st.session_state.workflow
    if workflow is None:
        st.warning("Please initialize LegalEase AI first by uploading a PDF or enabling general chat.")
        return

    st.session_state.chat_history.append({"role": "user", "content": prompt})
    try:
        result = workflow.analyze_document(prompt, thread_id=st.session_state.thread_id)
        response = _extract_final_response(result)
        st.session_state.chat_history.append({"role": "assistant", "content": response})
        st.session_state.last_error = None
    except Exception as exc:
        st.session_state.last_error = str(exc)
        st.session_state.chat_history.append(
            {
                "role": "assistant",
                "content": "I could not complete that request. Please check the API configuration and try again.",
            }
        )


def display_agent_info() -> None:
    agents = [
        ("🔍", "Legal Researcher", "Cases, precedents and legal research"),
        ("📋", "Contract Analyst", "Clauses, obligations and document review"),
        ("🎯", "Legal Strategist", "Risks, options and next steps"),
    ]
    for icon, name, description in agents:
        st.markdown(
            f'<div class="agent-card"><strong>{icon} {name}</strong><br><small>{description}</small></div>',
            unsafe_allow_html=True,
        )


def main() -> None:
    initialize_session_state()
    st.markdown('<h1 class="main-header">⚖️ LegalEase AI</h1>', unsafe_allow_html=True)
    st.markdown(
        '<p style="text-align:center;font-size:1.1rem;color:#666">Multi-agent legal document analysis and research assistant</p>',
        unsafe_allow_html=True,
    )

    with st.sidebar:
        st.header("📁 Documents")
        uploaded_files = st.file_uploader(
            "Upload legal PDFs",
            type=["pdf"],
            accept_multiple_files=True,
            help="Upload one or more contracts, notices or legal documents.",
        )

        general_chat = st.button("🤖 Start General Legal Chat", use_container_width=True)
        if general_chat and st.session_state.workflow is None:
            with st.spinner("Initializing AI agents..."):
                try:
                    st.session_state.workflow = create_workflow([])
                    st.session_state.documents_loaded = False
                    st.rerun()
                except Exception as exc:
                    st.error(f"Initialization failed: {exc}")

        if uploaded_files:
            signature = files_signature(uploaded_files)
            if signature != st.session_state.last_files_signature:
                with st.spinner("Reading PDFs and building the document knowledge base..."):
                    try:
                        docs = load_documents_from_upload(uploaded_files)
                        st.session_state.workflow = create_workflow(docs)
                        st.session_state.documents_loaded = bool(docs)
                        st.session_state.last_files_signature = signature
                        st.session_state.chat_history = []
                        st.session_state.last_error = None
                        st.rerun()
                    except Exception as exc:
                        st.session_state.last_error = str(exc)
                        st.error(f"PDF processing failed: {exc}")

        st.divider()
        st.subheader("🤖 Agents")
        display_agent_info()

        st.divider()
        st.subheader("⚙️ Configuration")
        cfg = get_config()
        st.caption(f"Provider: {cfg['provider']}")
        st.caption(f"Model: {cfg['model']}")
        if st.session_state.workflow:
            count = len(st.session_state.workflow.documents)
            st.success(f"Workflow ready • {count} document chunks")
        else:
            st.info("Upload a PDF or start general chat.")

        problems = validate_environment()
        if problems:
            with st.expander("Configuration notes"):
                for problem in problems:
                    st.warning(problem)

        if st.button("🗑️ Reset Session", use_container_width=True):
            for key in ["workflow", "chat_history", "last_files_signature", "documents_loaded", "last_error"]:
                st.session_state.pop(key, None)
            st.rerun()

    if st.session_state.workflow is None:
        st.info("Upload a legal PDF, or choose **Start General Legal Chat** in the sidebar.")
        st.markdown(
            """
            ### What LegalEase can do
            - 📋 Contract and document review
            - 🔍 Legal research and precedent discovery
            - ⚠️ Risk and compliance analysis
            - 🎯 Structured strategy and next-step planning
            """
        )
    else:
        st.markdown('<h2 class="sub-header">💬 Legal AI Chat</h2>', unsafe_allow_html=True)
        for chat in st.session_state.chat_history:
            with st.chat_message(chat["role"]):
                st.markdown(chat["content"])

        prompt = st.chat_input("Ask about the uploaded documents or a legal-information topic...")
        if prompt:
            with st.spinner("AI agents are analyzing..."):
                process_message(prompt)
            st.rerun()

        st.divider()
        st.subheader("⚡ Quick Actions")
        questions = {
            "📋 Contract Review": "Review the uploaded document and identify key terms, obligations, ambiguities and material risks.",
            "🔍 Legal Research": "Research the legal issues raised by the uploaded document and identify relevant authorities if available.",
            "⚠️ Risk Assessment": "Identify material legal, contractual and compliance risks in the uploaded document and explain why they matter.",
            "🎯 Strategy": "Based on the available document evidence, outline practical options, assumptions, risks and next steps.",
        }
        cols = st.columns(4)
        for col, (label, question) in zip(cols, questions.items()):
            if col.button(label, use_container_width=True):
                with st.spinner("AI agents are analyzing..."):
                    process_message(question)
                st.rerun()

        if st.button("🧹 Clear Chat"):
            st.session_state.chat_history = []
            st.rerun()

        if st.session_state.last_error:
            with st.expander("Technical error details"):
                st.code(st.session_state.last_error)

    st.markdown(
        '<div class="disclaimer">⚖️ LegalEase AI provides legal-information assistance and document analysis. It is not a law firm and does not replace advice from a qualified lawyer. Verify current law, jurisdiction and deadlines with a licensed professional.</div>',
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
