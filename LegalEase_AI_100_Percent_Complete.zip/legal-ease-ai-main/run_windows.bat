@echo off
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -e .
if not exist .env copy .env.example .env
streamlit run streamlit_app.py
